1. UNZIP Attacker_GUI.zip
2. go into Attacker
3. Run the FTP server
4. Run the HTTP server
   -- Specify Files directory (ip.txt, user.txt,...)
5. Run the brute-gui.exe
5. Run the brute_client.exe in all your Attacker Hosts.
   -- In this case my server is an atacker also.
6. Setup your configurations (IP, FTP, ...)
7. Load your configured data into remote nodes
8. Load ID for each attacker
9. Start attack
10. Will see the logger in FTP DIRECTORY
11. STOP - If you want